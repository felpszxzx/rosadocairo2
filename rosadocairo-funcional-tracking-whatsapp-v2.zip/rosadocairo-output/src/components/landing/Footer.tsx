import logoAsset from "@/assets/logo.asset.json";
import { whatsappLink, trackEvent } from "@/lib/site";

export function Footer() {
  return (
    <footer className="border-t border-border/60 bg-[var(--cream)]/80 py-12" role="contentinfo">
      <div className="mx-auto max-w-7xl px-4 sm:px-8">
        <div className="flex flex-col items-center gap-8 text-center">
          {/* Logo */}
          <a href="#top" aria-label="Rosa do Cairo Semijoias — Voltar ao topo">
            <img src={logoAsset.url} alt="Rosa do Cairo Semijoias" className="h-12 w-auto opacity-90" />
          </a>

          {/* Tagline */}
          <p className="max-w-md text-sm text-muted-foreground">
            Semijoias femininas com banho de ouro 18k, garantia real e atendimento humano.
            Cada peça escolhida com cuidado, entregue com carinho.
          </p>

          {/* Links sociais + navegação */}
          <nav aria-label="Links do rodapé" className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            <a
              href="https://www.instagram.com/rosadocairosemijoias/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-muted-foreground transition-colors hover:text-primary"
              aria-label="Rosa do Cairo no Instagram"
            >
              <svg viewBox="0 0 24 24" fill="currentColor" className="h-3.5 w-3.5" aria-hidden="true">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
              </svg>
              @rosadocairosemijoias
            </a>
            <span className="h-3 w-px bg-border" aria-hidden="true" />
            <a href="#catalogo" className="text-xs uppercase tracking-wider text-muted-foreground transition-colors hover:text-primary">
              Catálogo
            </a>
            <span className="h-3 w-px bg-border" aria-hidden="true" />
            <a href="#faq" className="text-xs uppercase tracking-wider text-muted-foreground transition-colors hover:text-primary">
              FAQ
            </a>
            <span className="h-3 w-px bg-border" aria-hidden="true" />
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackEvent("whatsapp_click", { location: "footer", label: "Footer WhatsApp" })}
              className="text-xs uppercase tracking-wider text-muted-foreground transition-colors hover:text-primary"
            >
              WhatsApp
            </a>
          </nav>

          {/* Rodapé legal */}
          <div className="border-t border-border/40 pt-6 w-full text-center">
            <p className="text-xs text-muted-foreground/70">
              © {new Date().getFullYear()} Rosa do Cairo Semijoias. Todos os direitos reservados.
            </p>
            <p className="mt-1 text-xs text-muted-foreground/50">
              CNPJ: XX.XXX.XXX/XXXX-XX · Atendimento: contato@rosadocairo.com.br
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
